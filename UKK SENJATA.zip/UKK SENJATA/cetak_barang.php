
<?php
require 'dompdf/autoload.inc.php';
use Dompdf\Dompdf;

include 'db.php';


$query = "SELECT * FROM barang";
$result = mysqli_query($koneksi, $query);

// HTML
$html = '
    <h2 style="text-align:center;">Daftar senjata di gudang</h2>
    <table border="1" cellpadding="8" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Barang</th>
                <th>Kategori</th>
                <th>Jumlah</th>
                <th>Harga</th>
                <th>Tanggal Masuk</th>
                <th>Deskripsi Senjata</th>
            </tr>
        </thead>
        <tbody>';

$no = 1;
while ($row = mysqli_fetch_assoc($result)) {
    $html .= '<tr>
        <td>' . $no++ . '</td>
        <td>' . htmlspecialchars($row['nama_barang']) . '</td>
        <td>' . htmlspecialchars($row['kategori_barang']) . '</td>
        <td>' . $row['jumlah'] . '</td>
        <td>Rp' . number_format($row['harga'], 0, ',', '.') . '</td>
        <td>' . $row['tgl'] . '</td>
        <td>' . htmlspecialchars($row['deskripsi']) . '</td>
    </tr>';
}

$html .= '
        </tbody>
    </table>
';

// objek Dompdf
$dompdf = new Dompdf();
$dompdf->loadHtml($html);

// ukuran dan orientasi halaman
$dompdf->setPaper('A4', 'landscape');

// Render ke PDF
$dompdf->render();

// Output PDF ke browser
$dompdf->stream("data_barang.pdf", ["Attachment" => false]);
exit;
?>
