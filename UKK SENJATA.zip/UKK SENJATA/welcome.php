<?php
session_start();
if (!isset($_SESSION['admin'])) {
  header("Location: login.php");
  exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Selamat Datang, Pasukan Bayanganku!</title>
  <link rel="icon" href="121.jpg" type="image/x-icon">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <style>
    body, html {
      margin: 0;
      padding: 0;
      height: 100%;
      overflow: hidden;
      display: flex;
      justify-content: center;
      align-items: center;
      background-color: black;
      color: white;
      font-family: 'Segoe UI', sans-serif;
    }

    video {
      position: fixed;
      top: 0;
      left: 0;
      object-fit: cover;
      width: 100%;
      height: 100%;
      z-index: 1;
    }

    .welcome-container {
      text-align: center;
      z-index: 2;
      position: absolute;
    }

    h1 {
      font-size: 3rem;
      animation: fadeIn 2s ease-in-out;
      margin: 10px 0;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .progress-container {
      width: 100%;
      height: 10px;
      background-color: rgba(255, 255, 255, 0.2);
      border-radius: 5px;
      margin: 20px auto 0;
      overflow: hidden;
    }

    .progress-bar {
      height: 200%;
      width: 0%;
      background-color: gold;
      animation: progressAnim 15s linear forwards;
    }

    @keyframes progressAnim {
      from { width: 0%; }
      to { width: 100%; }
    }

    #countdown {
      font-size: 2rem;
      margin-top: 10px;
      animation: fadeIn 2s ease-in-out;
    }

    #quote {
      color: white;
      font-weight: bold;
      font-style: italic;
      font-size: 1.5rem;
      opacity: 0;
      animation: fadeQuote 4s ease-in-out 2s forwards;
    }

    @keyframes fadeQuote {
      to { opacity: 1; }
    }

    .glow-logo {
      width: 120px;
      margin-bottom: 20px;
      animation: pulse 2s infinite;
    }

    @keyframes pulse {
      0% { filter: drop-shadow(0 0 2px gold); }
      50% { filter: drop-shadow(0 0 15px gold); }
      100% { filter: drop-shadow(0 0 2px gold); }
    }

    #transition-overlay {
      position: fixed;
      top: 0; left: 0;
      width: 100%;
      height: 100%;
      background: black;
      opacity: 0;
      z-index: 999;
      transition: opacity 1s ease;
      pointer-events: none;
    }
  </style>
</head>

<body>

  <!-- Video Latar -->
  <video autoplay muted>
    <source src="shadow.mp4" type="video/mp4">
    Browser tidak mendukung video.
  </video>

  <!-- Audio Musik -->
  <audio id="bg-music">
    <source src="purgatorium.mp3" type="audio/mpeg">
  </audio>

  <!-- Overlay Transisi -->
  <div id="transition-overlay"></div>

  <!-- Konten Loading -->
  <div class="welcome-container">
   <h1>Selamat Datang, Rajaku!</h1>
    <div id="quote">"Bayangan kematian selalu mengintai kalian dimanapun."</div>
    <div class="progress-container">
      <div class="progress-bar"></div>
    </div>
    <div id="countdown">15</div>
  </div>

  <!-- Script -->
  <script>
    // Mainkan audio saat halaman siap
    window.addEventListener("DOMContentLoaded", function () {
      const audio = document.getElementById("bg-music");
      audio.play().catch(() => {
        console.log("Autoplay dicegah. Menunggu interaksi pengguna.");
      });

      // Countdown angka
      let time = 15;
      const countdown = document.getElementById("countdown");
      const timer = setInterval(() => {
        time--;
        countdown.textContent = time;
        if (time <= 0) clearInterval(timer);
      }, 1000);

      // Fade out & redirect setelah 15 detik
      setTimeout(() => {
        document.getElementById("transition-overlay").style.opacity = 1;
        setTimeout(() => {
          window.location.href = "dashboard.php";
        }, 2000); // waktu untuk fade-out
      }, 15500);
    });
  </script>

</body>
</html>
