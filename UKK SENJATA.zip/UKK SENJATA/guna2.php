<?php
include 'db.php';
session_start();

$message = ''; // Inisialisasi variabel pesan

// Cek apakah admin sudah login
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add'])) {
    $nama_karyawan = trim($_POST['nama_karyawan']);
    $barang_id = intval($_POST['barang_id']);
    $jumlah = intval($_POST['jumlah']);
    $foto_karyawan_path = '';
    $foto_barang_path = ''; // Tambahkan variabel foto_barang_path

    // Validasi jumlah
    if ($jumlah <= 0) {
        $message = "Jumlah barang harus lebih dari 0!";
    }

    // Proses upload foto karyawan
    if (!empty($_FILES['foto_karyawan']['name'])) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $file_type = mime_content_type($_FILES['foto_karyawan']['tmp_name']);
        if (in_array($file_type, $allowed_types)) {
            $foto_karyawan_tmp = $_FILES['foto_karyawan']['tmp_name'];
            $foto_karyawan_name = time() . '_karyawan_' . basename($_FILES['foto_karyawan']['name']);
            $foto_karyawan_path = 'uploads/' . $foto_karyawan_name;
            move_uploaded_file($foto_karyawan_tmp, $foto_karyawan_path);
        } else {
            $message = "Hanya file gambar (JPEG, PNG, GIF) yang diperbolehkan untuk foto karyawan!";
        }
    }

    // Proses upload foto barang
    if (!empty($_FILES['foto_barang']['name'])) {
        $file_type = mime_content_type($_FILES['foto_barang']['tmp_name']);
        if (in_array($file_type, $allowed_types)) {
            $foto_barang_tmp = $_FILES['foto_barang']['tmp_name'];
            $foto_barang_name = time() . '_barang_' . basename($_FILES['foto_barang']['name']);
            $foto_barang_path = 'uploads/' . $foto_barang_name;
            move_uploaded_file($foto_barang_tmp, $foto_barang_path);
        } else {
            $message = "Hanya file gambar (JPEG, PNG, GIF) yang diperbolehkan untuk foto barang!";
        }
    }

    // Simpan data ke database jika tidak ada error
    if (empty($message)) {
        $stmt = $koneksi->prepare("INSERT INTO penggunaan (nama_karyawan, foto_karyawan, barang_id, jumlah, foto_barang) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("ssiss", $nama_karyawan, $foto_karyawan_path, $barang_id, $jumlah, $foto_barang_path);

        if ($stmt->execute()) {
            header("Location: guna.php?message=added");
            exit;
        } else {
            $message = "Terjadi kesalahan: " . $stmt->error;
        }
        $stmt->close();
    }
}

// Handle delete
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $stmt = $koneksi->prepare("DELETE FROM penggunaan WHERE id = ?");
    $stmt->bind_param("i", $delete_id);
    if ($stmt->execute()) {
        header("Location: guna.php?message=deleted");
        exit;
    }
}

// Fetch data barang untuk dropdown
$barang_result = mysqli_query($koneksi, "SELECT * FROM barang");

// Fetch data penggunaan
$penggunaan_result = mysqli_query($koneksi, "
    SELECT 
        penggunaan.id, 
        penggunaan.nama_karyawan, 
        penggunaan.foto_karyawan, 
        penggunaan.foto_barang, 
        barang.nama_barang, 
        penggunaan.jumlah 
    FROM penggunaan
    JOIN barang ON penggunaan.barang_id = barang.id
");

if (!$penggunaan_result) {
    die("Query gagal: " . mysqli_error($koneksi));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Penggunaan Barang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="121.jpg">
    
</head>
<body>
    <div class="container mt-5">
<h2 class="text-center" >Form Input Penggunaan Barang</h2>
<form method="POST" action="guna.php" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="nama_karyawan" class="form-label">Nama Karyawan</label>
            <input type="text" class="form-control" id="nama_karyawan" name="nama_karyawan" required>
        </div>
        <div class="mb-3">
            <label for="foto_karyawan" class="form-label">Foto Karyawan</label>
            <input type="file" class="form-control" id="foto_karyawan" name="foto_karyawan" accept="image/*">
        </div>
        <div class="mb-3">
            <label for="barang_id" class="form-label">Nama Barang</label>
            <select class="form-select" id="barang_id" name="barang_id" required>
                <option value="">Pilih Barang</option>
                <?php while ($barang = mysqli_fetch_assoc($barang_result)) : ?>
                    <option value="<?php echo $barang['id']; ?>"><?php echo $barang['nama_barang']; ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="foto_barang" class="form-label">Foto Barang</label>
            <input type="file" class="form-control" id="foto_barang" name="foto_barang" accept="image/*">
        </div>
        <div class="mb-3">
            <label for="jumlah" class="form-label">Jumlah Barang</label>
            <input type="number" class="form-control" id="jumlah" name="jumlah" min="1" required>
        </div>
        <button type="submit" class="btn btn-primary" name="add">Simpan</button>
        <a href="guna.php" class="btn btn-secondary">Kembali</a>
        </form>
        </div>
        </body>
        </html>
