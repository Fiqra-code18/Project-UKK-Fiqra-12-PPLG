<?php
include 'db.php';
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

// Statistik Total
$query_total_barang = "SELECT SUM(jumlah) AS total_barang FROM barang";
$query_total_harga = "SELECT SUM(harga * jumlah) AS total_harga FROM barang";
$data_total_barang = mysqli_fetch_assoc(mysqli_query($koneksi, $query_total_barang));
$data_total_harga = mysqli_fetch_assoc(mysqli_query($koneksi, $query_total_harga));

// Statistik Kategori
$query_kategori = "SELECT kategori_barang, COUNT(*) AS jumlah FROM barang GROUP BY kategori_barang";
$result_kategori = mysqli_query($koneksi, $query_kategori);

// Barang Hampir Habis
$query_menipis = "SELECT * FROM barang WHERE jumlah < 15 ORDER BY jumlah ASC LIMIT 15";
$result_menipis = mysqli_query($koneksi, $query_menipis);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Admin</title>
    <link rel="icon" type="image/x-icon" href="121.jpg">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css?v=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        
        body {
        opacity: 0;
        transition: opacity 1s ease-in-out;
    }

    body.fade-in {
        opacity: 1;
    }
    </style>
</head>
<body>


<?php $currentPage = basename($_SERVER['PHP_SELF']); ?>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-0">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Gudang Senjata</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
    </div>
</nav>

<div class="d-flex">
    <div class="bg-dark text-white p-3 vh-100" style="width: 220px; position: sticky; top: 0;">
        <h5 class="mb-4 text-center">MENU</h5>
        <ul class="nav flex-column">
            <li class="nav-item mb-2">
                <a class="nav-link text-white <?= $currentPage == 'dashboard.php' ? 'active bg-primary' : '' ?>" href="dashboard.php">🏠 Dashboard</a>
            </li>
            <li class="nav-item mb-2">
                <a class="nav-link text-white <?= $currentPage == 'index.php' ? 'active bg-primary' : '' ?>" href="index.php">📦 Data Barang</a>
            </li>
            <li class="nav-item mb-2">
                <a class="nav-link text-white <?= $currentPage == 'guna.php' ? 'active bg-primary' : '' ?>" href="guna.php">📝 Data Penggunaan</a>
            </li>
            <li class="nav-item mt-4">
                <a href="cetak_barang.php" target="_blank" class="btn btn-success mt-3">
                    <i class="bi bi-printer"></i> Cetak PDF
                </a>
            </li>
            <li class="nav-item mt-4">
                <a class="btn btn-danger w-100" href="logout.php">Logout</a>
            </li>
        </ul>
    </div>

    <div class="container-fluid p-4">
        <div class="alert alert-info">
            Selamat datang, <strong><?= $_SESSION['admin']; ?></strong>! Semangat bekerja 💼
        </div>

        <div class="row g-4">
            <div class="col-md-6">
                <div class="card text-center">
                    <div class="card-body">
                        <h5>Total Barang Keseluruhan</h5>
                        <p class="fw-bold fs-4"><?= $data_total_barang['total_barang']; ?> Unit</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card text-center">
                    <div class="card-body">
                        <h5>Total Nilai Barang</h5>
                        <p class="fw-bold fs-4">Rp<?= number_format($data_total_harga['total_harga'], 0, ',', '.'); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4 mt-4">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Statistik Barang per Kategori</h5>
                        <ul class="list-group">
                            <?php mysqli_data_seek($result_kategori, 0); while($row = mysqli_fetch_assoc($result_kategori)): ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <?= $row['kategori_barang']; ?>
                                    <span class="badge bg-primary rounded-pill"><?= $row['jumlah']; ?></span>
                                </li>
                            <?php endwhile; ?>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card p-3">
                    <h5 class="card-title text-center">Grafik Barang per Kategori</h5>
                    <canvas id="kategoriChart" height="200"></canvas>
                </div>
            </div>
        </div>

        <div class="card mt-4">
            <div class="card-body">
                <h5 class="card-title text-danger">Barang Hampir Habis (Stok < 15)</h5>
                <table class="table table-sm table-bordered">
                    <thead><tr><th>Nama Barang</th><th>Jumlah</th></tr></thead>
                    <tbody>
                        <?php while($row = mysqli_fetch_assoc($result_menipis)): ?>
                            <tr>
                                <td><?= $row['nama_barang']; ?></td>
                                <td><?= $row['jumlah']; ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Script Chart -->
<?php
$labels = [];
$data = [];
mysqli_data_seek($result_kategori, 0);
while ($row = mysqli_fetch_assoc($result_kategori)) {
    $labels[] = $row['kategori_barang'];
    $data[] = $row['jumlah'];
}
?>
<script>
    const ctx = document.getElementById('kategoriChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: <?= json_encode($labels); ?>,
            datasets: [{
                label: 'Jumlah Barang',
                data: <?= json_encode($data); ?>,
                backgroundColor: 'rgba(54, 162, 235, 0.7)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        }
    });
</script>

<script>
    window.addEventListener('DOMContentLoaded', function () {
        document.body.classList.add('fade-in');
    });
</script>


</body>
</html>
