<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "inventaris_db";

$koneksi = mysqli_connect(hostname: $host, username: $user, password: $pass, database: $db);

if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
