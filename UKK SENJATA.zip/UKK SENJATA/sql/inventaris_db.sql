-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 21, 2025 at 06:01 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventaris_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(492, 'Fiqra Zulmardi Pohan', '$2y$10$JbHerZtITptA7Zyq3yMnM.WPqOYNA3M2nXNv85GKksW7kNdTn/3PC'),
(493, 'Fiqra Zulmardi Pohan', '$2y$10$EmkMjYFXx0QRNrAGcyir/u42OmyHsvkS2rMMZzjGzaa5DrRzS.gYi'),
(494, 'Fiqra Zulmardi Pohan', '$2y$10$f2bzutsCOnGFqYwlg3DtRuujd2kNliW0y0IVXeoL9r0pAHxCVIXKa'),
(495, 'Fiqra Zulmardi Pohan', '$2y$10$s3HFAPqoY8b80zQospbliO3a8KOQsYh.djJhMucp5UyKQonSVuI6W'),
(496, 'Fiqra Zulmardi Pohan', '$2y$10$jexLI741J3BzFjZcTU.8M.pqO0F4UQ9IjFUD5n/b8sKLYJ9U7WgaK'),
(497, 'Fiqra Zulmardi Pohan', '$2y$10$HJG7ufjHVVOQv/teWxvsu.y17ptGmtfLiv4/dgOZzr8M4su1wvxyO'),
(498, 'Fiqra Zulmardi Pohan', '$2y$10$wur9yNTVFP3UWTTirVN4ee0KaT/LLV1CwIfESJar5DTXMxj9F.1d.'),
(499, 'Fiqra Zulmardi Pohan', '$2y$10$P7PDgzm6AVgM280D48lJ7OqWYFg2KKUVyylB0Ia5h7RW2BwtR7Npu'),
(500, 'Fiqra Zulmardi Pohan', '$2y$10$vMjpS5W57BT3qe8SkJRpfel.52A7j.bx3wsK8gB4z0s8H290vEJUq'),
(501, 'Fiqra Zulmardi Pohan', '$2y$10$Bzrq.eGCG0zn.3qV/MWJ5e/y..qzxSO9o/h2AayXezhFy4f4QmbWG'),
(502, 'Fiqra Zulmardi Pohan', '$2y$10$Y0mcambLvcprYY7frfwSWufVXr84tjVnoK9Ooi20h0VEvYN/4nTDG'),
(503, 'Fiqra Zulmardi Pohan', '$2y$10$dTlFs/mbUV9CMrSpS7/YKOUbvG.eQMq6u8YchJY5mKo0P6DPf/YYW'),
(504, 'Fiqra Zulmardi Pohan', '$2y$10$Mbzugq15x/qADGA8S.mD.u5UIx0l193uxHyaIo8DavruZmEitm3rS'),
(505, 'Fiqra Zulmardi Pohan', '$2y$10$TB5dSChZ3tDK5CtADPO0FeL6A460WUbUAsRVbk2QiDWdLMq5C6WYO'),
(506, 'Fiqra Zulmardi Pohan', '$2y$10$OaTys.8DY2BbceQ3D.Uzs.mxy7Pxx5zL0xP5RBHs.0LKeuQeyQX9a'),
(507, 'Fiqra Zulmardi Pohan', '$2y$10$a9LUzi3l1PwIPgLexW3cQePqNQW7wV1PC/W5cDuX8tXeh3ujqvdrq'),
(508, 'Fiqra Zulmardi Pohan', '$2y$10$G/ogHhq2LaiVJBCyR/sHJ.u5GPGL.DSSgoINgrXLxSBDchSDrN9kS'),
(509, 'Fiqra Zulmardi Pohan', '$2y$10$0aDQFSX6sjAiwDU5FsjwFu1sB9pKbuALwvtRwPx31uWNq4eI4m8Um'),
(510, 'Fiqra Zulmardi Pohan', '$2y$10$DJjYJf/7iHRwnaT0y/iuauZp2nk7Hbw3fW5wsJqCsPkh4Kz8ETNSG'),
(511, 'Fiqra Zulmardi Pohan', '$2y$10$6rZQS3FI6kf3BUP5zh3RJeEQwhkG2eCoVnZFs7RN8a.6SkGNfhEuS'),
(512, 'Fiqra Zulmardi Pohan', '$2y$10$u5kXQ7Nj7TccNx0kHFtWUuLzHvlFvuVCBhgjS3AEygyT/mZmQ1BQC'),
(513, 'Fiqra Zulmardi Pohan', '$2y$10$xAW0b.fTGcefn2zR18yor.oIXOH5TCbSNJ7XBJ869Sr2t7p.HLFqa'),
(514, 'Fiqra Zulmardi Pohan', '$2y$10$ASO4LEHLZpf/XoE2O8NWZ./RwBU0jIRY3/kGN4HoVVH1sUPtzT7aq'),
(515, 'Fiqra Zulmardi Pohan', '$2y$10$2kh3L9RtFjWvYFQROVErCOBnuQvbfTk2tFCFyD75TEE1JfOo1yLk6'),
(516, 'Fiqra Zulmardi Pohan', '$2y$10$YH1zgO.nWAN31d0XMnlbEucIf4xCtDFcKw/izUQZ38Ly9s9C8C3s6'),
(517, 'Fiqra Zulmardi Pohan', '$2y$10$VJByjnZPFRDIgjhvCS/iwuuCZkH4sHZJdiDWMoGI81HeZnE9hx0Rm'),
(518, 'Fiqra Zulmardi Pohan', '$2y$10$fg4SCBfyidsvNDS38VG7QuEIIqSxr3yE2Egs.Zzu4AGprMz4/cpAW'),
(519, 'Fiqra Zulmardi Pohan', '$2y$10$Zes2ZxQAwP139d0it648oOWgL1t9Dqc/su3UL48W3cbPV.WngL2sK'),
(520, 'Fiqra Zulmardi Pohan', '$2y$10$BOYG0UhNIqT4irpX3yP6GucukW4FXN/cM55GhC7.tU54fMDPOS3g.');

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `id` int(11) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `kategori_barang` varchar(100) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga` decimal(10,2) NOT NULL,
  `foto_barang` varchar(255) DEFAULT NULL,
  `tgl` date NOT NULL,
  `deskripsi` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`id`, `nama_barang`, `kategori_barang`, `jumlah`, `harga`, `foto_barang`, `tgl`, `deskripsi`) VALUES
(60, 'AK47', 'Assault Rifle', 12, 5000000.00, 'Screenshot 2025-04-19 230729.png', '2024-02-02', 'diskon');

-- --------------------------------------------------------

--
-- Table structure for table `karyawan`
--

CREATE TABLE `karyawan` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `foto` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `penggunaan`
--

CREATE TABLE `penggunaan` (
  `id` int(11) NOT NULL,
  `nama_karyawan` varchar(11) NOT NULL,
  `foto_karyawan` varchar(255) NOT NULL,
  `barang_id` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `foto_barang` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `karyawan`
--
ALTER TABLE `karyawan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `penggunaan`
--
ALTER TABLE `penggunaan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `barang_id` (`barang_id`),
  ADD KEY `fk_penggunaan_karyawan` (`nama_karyawan`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=521;

--
-- AUTO_INCREMENT for table `barang`
--
ALTER TABLE `barang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `karyawan`
--
ALTER TABLE `karyawan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `penggunaan`
--
ALTER TABLE `penggunaan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `penggunaan`
--
ALTER TABLE `penggunaan`
  ADD CONSTRAINT `penggunaan_ibfk_2` FOREIGN KEY (`barang_id`) REFERENCES `barang` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
