<?php
include 'db.php';
session_start();
$hashed_password = password_hash('15-10-2007', PASSWORD_DEFAULT);
mysqli_query($koneksi, "INSERT INTO admin (username, password) VALUES ('Fiqra Zulmardi Pohan', '$hashed_password')");
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" type="image/x-icon" href="121.jpg">
  <title>Bangunlah!</title>
  <style>
    .video-bg {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      object-fit: cover;
      z-index: -1;
    }

    body {
      margin: 0;
      padding: 0;
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      overflow: hidden;
      font-family: sans-serif;
    }

    .login-container {
      background: rgba(20, 20, 20, 0.95);
      padding: 25px;
      border-radius: 15px;
      box-shadow: 0 0 15px rgba(0, 0, 0, 0.5);
      max-width: 320px;
      width: 100%;
      display: none;
      position: absolute;
      z-index: 1;
      color: #fff;
    }

    .form-control, .form-label {
      background-color: transparent;
      color: white;
    }

    .form-control::placeholder {
      color: #ccc;
    }

    .input-group-text {
      background-color: #333;
      color: white;
      border: none;
    }

    .btn-primary {
      width: 100%;
      border-radius: 8px;
    }

    .btn-secondary {
      width: 100%;
      margin-top: 10px;
    }

    .title-click {
      color: white;
      font-size: 2.5rem;
      cursor: pointer;
      position: relative;
      z-index: 1;
      transition: transform 0.3s;
    }

    .title-click:hover {
      transform: scale(1.05);
    }
  </style>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>
<body>

  
  <video class="video-bg" autoplay muted loop>
    <source src="jinwoo.mp4" type="video/mp4">
  </video>

  
  <audio id="ariseSound" src="arise.m4a"></audio>

  
  <div class="title-click text-center" onclick="triggerArise()">Arise!</div>

 
  <div class="login-container">
    <form action="" method="POST">
      <div class="mb-3">
        <label for="username" class="form-label">Username</label>
        <div class="input-group">
          <span class="input-group-text"><i class="fa fa-user"></i></span>
          <input type="text" class="form-control" name="username" placeholder="Enter your username" required>
        </div>
      </div>
      <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <div class="input-group">
          <span class="input-group-text"><i class="fa fa-lock"></i></span>
          <input type="password" class="form-control" name="password" placeholder="Enter your password" required>
        </div>
      </div>
      <button type="submit" name="login" class="btn btn-primary">Login</button>
      <a href="login.php" class="btn btn-secondary">Back</a>
    </form>

    <?php
    if (isset($_POST['login'])) {
      $username = $_POST['username'];
      $password = $_POST['password'];

      $query = "SELECT * FROM admin WHERE username='$username'";
      $result = mysqli_query($koneksi, $query);
      $admin = mysqli_fetch_assoc($result);

      if ($admin && password_verify($password, $admin['password'])) {
        $_SESSION['admin'] = $admin['username'];
        header("Location: welcome.php");
        exit;
      } else {
        echo "<div class='alert alert-danger mt-3 text-center'>Username atau password salah</div>";
      }
    }
    ?>
  </div>

  <script>
    function triggerArise() {
      const sound = document.getElementById('ariseSound');
      sound.play(); 
      document.querySelector('.login-container').style.display = 'block'; 
    }
  </script>
</body>
</html>
