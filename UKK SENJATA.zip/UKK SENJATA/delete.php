<?php
include 'db.php';
session_start();

$id = $_GET['id'];
$query = "DELETE FROM barang WHERE id = $id";
mysqli_query($koneksi, $query);

header("Location: index.php?status=deleted");
exit;
?>
