<?php include 'db.php'; 
include 'db.php';
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}


$id = $_GET['id'];
$query = "SELECT * FROM barang WHERE id = $id";
$result = mysqli_query($koneksi, $query);
$row = mysqli_fetch_assoc($result);
$existingImage = $row['foto_barang']; // Simpan nama file gambar yang sudah ada
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Barang</title>
    <link rel="icon" type="image/x-icon" href="121.jpg">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2 class="text-center">Edit Barang</h2>
    <form action="edit.php?id=<?= $id ?>" method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="nama_barang" class="form-label">Nama Barang</label>
            <input type="text" class="form-control" name="nama_barang" value="<?= $row['nama_barang'] ?>" required>
        </div>
        <div class="mb-3">
            <label for="kategori_barang" class="form-label">Kategori Barang</label>
            <input type="text" class="form-control" name="kategori_barang" value="<?= $row['kategori_barang'] ?>" required>
        </div>
        <div class="mb-3">
            <label for="jumlah" class="form-label">Jumlah</label>
            <input type="number" class="form-control" name="jumlah" value="<?= $row['jumlah'] ?>" required>
        </div>
        <div class="mb-3">
            <label for="harga" class="form-label">Harga</label>
            <input type="number" step="0.01" class="form-control" name="harga" value="<?= $row['harga'] ?>" required>
        </div>

        <!-- Tampilkan gambar yang sudah ada -->
        <div class="mb-3">
            <label for="foto_barang" class="form-label">Foto Barang</label><br>
            <img src="upload/<?= $existingImage ?>" alt="Foto Barang" class="img-thumbnail" width="150">
        </div>

        <!-- Input untuk mengunggah gambar baru -->
        <div class="mb-3">
            <label for="foto_barang" class="form-label">Ganti Foto Barang</label>
            <input type="file" class="form-control" name="foto_barang">
        </div>
        <div class="mb-3">
            <label for="tgl" class="form-label">Tanggal Masuk</label>
            <input type="date" class="form-control" id="tgl" name="tgl" required>
        </div>
        <div class="mb-3">
            <label for="deskripsi" class="form-label">deskripsi</label>
            <input type="text" class="form-control" id="deskripsi" name="deskripsi" required>
        </div>

        <button type="submit" name="update" class="btn btn-primary">Update</button>
        
        <a href="index.php" class="btn btn-secondary">Back</a>
    </form>
</div>

<?php
if (isset($_POST['update'])) {
    $nama_barang = $_POST['nama_barang'];
    $kategori_barang = $_POST['kategori_barang'];
    $jumlah = $_POST['jumlah'];
    $harga = $_POST['harga'];
    $tgl = $_POST['tgl'];
    $deskripsi = $_POST['deskripsi'];

    // Proses upload gambar baru jika ada
    if (!empty($_FILES['foto_barang']['name'])) {
        $foto_barang = $_FILES['foto_barang']['name'];
        $target_dir = "upload/";
        $target_file = $target_dir . basename($foto_barang);
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];

        // Periksa apakah file yang diupload adalah gambar yang valid
        if (in_array($imageFileType, $allowed_types)) {
            // Hapus gambar lama jika ada
            if (file_exists("upload/" . $existingImage)) {
                unlink("upload/" . $existingImage);
            }
            // Upload gambar baru
            move_uploaded_file($_FILES['foto_barang']['tmp_name'], $target_file);
        } else {
            echo "Tipe file tidak diizinkan. Hanya file JPG, JPEG, PNG, dan GIF yang diperbolehkan.";
        }
    } else {
        $foto_barang = $existingImage; // Tetap gunakan gambar lama jika tidak ada gambar baru yang diupload
    }

    $query = "UPDATE barang SET nama_barang='$nama_barang', kategori_barang='$kategori_barang', jumlah='$jumlah', harga='$harga', foto_barang='$foto_barang', tgl='$tgl', deskripsi='$deskripsi' WHERE id=$id";
    header("Location: index.php?status=updated");
exit;
}

?>
</body>
</html>
