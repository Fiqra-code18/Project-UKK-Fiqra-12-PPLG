<?php
include 'db.php';
session_start();

// Pastikan pengguna sudah login sebagai admin
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

$message = "";
$id = $_GET['id'] ?? null;

// Cek apakah ID ada
if (!$id) {
    header("Location: guna.php");
    exit;
}

// Ambil data yang ada berdasarkan ID
$stmt = $koneksi->prepare("SELECT * FROM penggunaan WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_assoc();
$stmt->close();

if (!$data) {
    header("Location: guna.php?message=Data tidak ditemukan");
    exit;
}

// Jika form dikirimkan
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_karyawan = trim($_POST['nama_karyawan']);
    $barang_id = $_POST['barang_id'];
    $jumlah = $_POST['jumlah'];

    // Validasi input
    if (empty($nama_karyawan) || empty($barang_id) || empty($jumlah) || $jumlah <= 0) {
        $message = "Semua data wajib diisi dengan benar.";
    } else {
        // Mulai dengan path foto karyawan dan foto barang yang lama
        $foto_karyawan_path = $data['foto_karyawan']; 
        $foto_barang_path = $data['foto_barang']; 

        // Proses upload foto karyawan jika ada yang baru
        if (isset($_FILES['foto_karyawan']) && $_FILES['foto_karyawan']['error'] === UPLOAD_ERR_OK) {
            $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
            $file_type = mime_content_type($_FILES['foto_karyawan']['tmp_name']);
            $file_size = $_FILES['foto_karyawan']['size'];

            if (!in_array($file_type, $allowed_types)) {
                $message = "Jenis file foto karyawan tidak didukung (hanya JPG, PNG, GIF).";
            } elseif ($file_size > 2 * 1024 * 1024) { // Maksimal 2MB
                $message = "Ukuran file foto karyawan terlalu besar (maksimal 2MB).";
            } else {
                $foto_karyawan_tmp = $_FILES['foto_karyawan']['tmp_name'];
                $foto_karyawan_name = time() . '_' . basename($_FILES['foto_karyawan']['name']);
                $foto_karyawan_path = 'uploads/' . $foto_karyawan_name;

                // Simpan file foto karyawan
                if (!move_uploaded_file($foto_karyawan_tmp, $foto_karyawan_path)) {
                    $message = "Gagal mengunggah file foto karyawan.";
                } else {
                    // Optional: Hapus foto karyawan lama jika ada dan berbeda dari default
                    if ($data['foto_karyawan'] && file_exists($data['foto_karyawan'])) {
                        unlink($data['foto_karyawan']);
                    }
                }
            }
        }

        // Proses upload foto barang jika ada yang baru
        if (isset($_FILES['foto_barang']) && $_FILES['foto_barang']['error'] === UPLOAD_ERR_OK) {
            $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
            $file_type = mime_content_type($_FILES['foto_barang']['tmp_name']);
            $file_size = $_FILES['foto_barang']['size'];

            if (!in_array($file_type, $allowed_types)) {
                $message = "Jenis file foto barang tidak didukung (hanya JPG, PNG, GIF).";
            } elseif ($file_size > 2 * 1024 * 1024) { // Maksimal 2MB
                $message = "Ukuran file foto barang terlalu besar (maksimal 2MB).";
            } else {
                $foto_barang_tmp = $_FILES['foto_barang']['tmp_name'];
                $foto_barang_name = time() . '_' . basename($_FILES['foto_barang']['name']);
                $foto_barang_path = 'uploads/' . $foto_barang_name;

                // Simpan file foto barang
                if (!move_uploaded_file($foto_barang_tmp, $foto_barang_path)) {
                    $message = "Gagal mengunggah file foto barang.";
                } else {
                    // Optional: Hapus foto barang lama jika ada dan berbeda dari default
                    if ($data['foto_barang'] && file_exists($data['foto_barang'])) {
                        unlink($data['foto_barang']);
                    }
                }
            }
        }

        // Update data ke database jika tidak ada pesan error
        if (!$message) {
            $stmt = $koneksi->prepare("UPDATE penggunaan SET nama_karyawan = ?, foto_karyawan = ?, foto_barang = ?, barang_id = ?, jumlah = ? WHERE id = ?");
            $stmt->bind_param("sssiii", $nama_karyawan, $foto_karyawan_path, $foto_barang_path, $barang_id, $jumlah, $id);

            if ($stmt->execute()) {
                $message = "Data berhasil diperbarui!";
                header("Location: guna.php?message=" . urlencode($message));
                exit;
            } else {
                $message = "Terjadi kesalahan: " . $stmt->error;
            }
            $stmt->close();
        }
    }
}

// Ambil daftar barang untuk dropdown
$barang_result = $koneksi->query("SELECT * FROM barang");

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Penggunaan Barang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2 class="text-center">Edit Data Penggunaan Barang</h2>
    <?php if ($message): ?>
        <div class="alert alert-info"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
    <form method="POST" enctype="multipart/form-data">
        <!-- Nama Karyawan -->
        <div class="mb-3">
            <label for="nama_karyawan" class="form-label">Nama Karyawan</label>
            <input type="text" class="form-control" id="nama_karyawan" name="nama_karyawan" value="<?php echo htmlspecialchars($data['nama_karyawan']); ?>" required>
        </div>
        <!-- Foto Karyawan -->
        <div class="mb-3">
            <label for="foto_karyawan" class="form-label">Foto Karyawan</label>
            <?php if ($data['foto_karyawan']): ?>
                <div class="mb-2">
                    <img src="<?php echo htmlspecialchars($data['foto_karyawan']); ?>" alt="Foto Karyawan" class="img-thumbnail" style="max-width: 150px;">
                </div>
            <?php endif; ?>
            <input type="file" class="form-control" id="foto_karyawan" name="foto_karyawan" accept="image/*">
            <small class="form-text text-muted">Kosongkan jika tidak ingin mengganti foto karyawan.</small>
        </div>
        <!-- Nama Barang -->
        <div class="mb-3">
            <label for="barang_id" class="form-label">Nama Barang</label>
            <select class="form-select" id="barang_id" name="barang_id" required>
                <option value="">-- Pilih Barang --</option>
                <?php while ($barang = mysqli_fetch_assoc($barang_result)) : ?>
                    <option value="<?php echo htmlspecialchars($barang['id']); ?>" <?php echo $barang['id'] == $data['barang_id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($barang['nama_barang']); ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        <!-- Foto Barang -->
        <div class="mb-3">
            <label for="foto_barang" class="form-label">Foto Barang</label>
            <?php if ($data['foto_barang']): ?>
                <div class="mb-2">
                    <img src="<?php echo htmlspecialchars($data['foto_barang']); ?>" alt="Foto Barang" class="img-thumbnail" style="max-width: 150px;">
                </div>
            <?php endif; ?>
            <input type="file" class="form-control" id="foto_barang" name="foto_barang" accept="image/*">
            <small class="form-text text-muted">Kosongkan jika tidak ingin mengganti foto barang.</small>
        </div>
        <!-- Jumlah Barang -->
        <div class="mb-3">
            <label for="jumlah" class="form-label">Jumlah Barang</label>
            <input type="number" class="form-control" id="jumlah" name="jumlah" value="<?php echo htmlspecialchars($data['jumlah']); ?>" min="1" required>
        </div>
        <!-- Tombol Simpan -->
        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
        <a href="guna.php" class="btn btn-secondary">Kembali</a>
    </form>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
