<?php
include 'db.php';
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

$limit = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $limit;

$search = isset($_GET['search']) ? mysqli_real_escape_string($koneksi, $_GET['search']) : '';
$kategori = isset($_GET['kategori']) ? mysqli_real_escape_string($koneksi, $_GET['kategori']) : '';

$query = "SELECT * FROM barang WHERE (nama_barang LIKE '%$search%' OR kategori_barang LIKE '%$search%')";
if ($kategori) {
    $query .= " AND kategori_barang = '$kategori'";
}
$query .= " LIMIT $start, $limit";
$result = mysqli_query($koneksi, $query);

$query_total = "SELECT COUNT(*) AS total FROM barang WHERE (nama_barang LIKE '%$search%' OR kategori_barang LIKE '%$search%')";
if ($kategori) {
    $query_total .= " AND kategori_barang = '$kategori'";
}
$result_total = mysqli_query($koneksi, $query_total);
$total_data = mysqli_fetch_assoc($result_total)['total'];
$total_page = ceil($total_data / $limit);
?>

<?php
$currentPage = basename($_SERVER['PHP_SELF']); 
?>


<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventaris</title>
    <link rel="icon" type="image/x-icon" href="121.jpg">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css?v=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-0">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Gudang Senjata</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
    </div>
</nav>

<div class="d-flex">
    <div class="bg-dark text-white p-3 vh-100" style="width: 220px; position: sticky; top: 0;">
        <h5 class="mb-4 text-center">MENU</h5>
        <ul class="nav flex-column">
        <li class="nav-item mb-2">
            <a class="nav-link text-white <?= $currentPage == 'dashboard.php' ? 'active bg-primary' : '' ?>" href="dashboard.php">🏠 Dashboard</a>
        </li>
        <li class="nav-item mb-2">
            <a class="nav-link text-white <?= $currentPage == 'index.php' ? 'active bg-primary' : '' ?>" href="index.php">📦 Data Barang</a>
        </li>
        <li class="nav-item mb-2">
            <a class="nav-link text-white <?= $currentPage == 'guna.php' ? 'active bg-primary' : '' ?>" href="guna.php">📝 Data Penggunaan</a>
        </li>
        <li class="nav-item mt-4">
            <a href="cetak_barang.php" target="_blank" class="btn btn-success mt-3">
                <i class="bi bi-printer"></i> Cetak PDF
            </a>
        </li>
        <li class="nav-item mt-4">
                <a class="btn btn-danger w-100" href="logout.php">Logout</a>
        </li>
        </ul>
    </div>

    <div class="container-fluid mt-4 flex-grow-1" style="margin-left: 0;">
        <div class="main-wrapper">
            <div class="container mt-4">
                <h2 class="text-center">Cari senjata apa hari ini tuan?</h2>
                <?php if (isset($_GET['status'])): ?>
    <?php if ($_GET['status'] == 'success'): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            Data berhasil <strong>ditambahkan</strong>.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Tutup"></button>
        </div>
    <?php elseif ($_GET['status'] == 'updated'): ?>
        <div class="alert alert-info alert-dismissible fade show" role="alert">
            Data berhasil <strong>diubah</strong>.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Tutup"></button>
        </div>
    <?php elseif ($_GET['status'] == 'deleted'): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            Data berhasil <strong>dihapus</strong>.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Tutup"></button>
        </div>
    <?php endif; ?>
<?php endif; ?>


                <form action="index.php" method="GET" class="d-flex mb-4">
                    <select name="kategori" class="form-select me-2">
                        <option value="">Semua Kategori</option>
                        <option value="Sniper" <?= $kategori == 'Sniper' ? 'selected' : '' ?>>Sniper</option>
                        <option value="Assault Rifle" <?= $kategori == 'Assault Rifle' ? 'selected' : '' ?>>Assault Rifle</option>
                        <option value="SMG" <?= $kategori == 'SMG' ? 'selected' : '' ?>>SMG</option>
                        <option value="Sword" <?= $kategori == 'Sword' ? 'selected' : '' ?>>Sword</option>
                        <option value="Dagger" <?= $kategori == 'Dagger' ? 'selected' : '' ?>>Dagger</option>
                    </select>
                    <input type="text" name="search" class="form-control me-2" placeholder="Cari Barang" value="<?= htmlspecialchars($search) ?>">
                    <button type="submit" class="btn btn-primary">Cari</button>
                    <a href="index.php" class="btn btn-secondary ms-2">Reset</a>
                </form>

                <table class="table table-bordered table-hover text-center">
                    <thead class="table-dark">
                        <tr>
                            <th>No</th>
                            <th>Nama Barang</th>
                            <th>Kategori</th>
                            <th>Jumlah stok</th>
                            <th>Harga (per satuan)</th>
                            <th>Foto</th>
                            <th>Tanggal masuk</th>
                            <th>Deskripsi Senjata</th>
                            <th>Opsi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = $start + 1;
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<tr>";
                            echo "<td>{$no}</td>";
                            
                            echo "<td style='cursor:pointer;' onclick=\"showInfo(
                                '" . htmlspecialchars($row['nama_barang'], ENT_QUOTES) . "',
                                '" . htmlspecialchars($row['kategori_barang'], ENT_QUOTES) . "',
                                '{$row['jumlah']}',
                                '{$row['harga']}',
                                '" . htmlspecialchars($row['foto_barang'], ENT_QUOTES) . "',
                                '{$row['tgl']}',
                                `" . htmlspecialchars($row['deskripsi'], ENT_QUOTES) . "` 
                            )\">{$row['nama_barang']}</td>";                            
                            echo "<td>{$row['kategori_barang']}</td>";
                            echo "<td>{$row['jumlah']}</td>";
                            echo "<td>Rp" . number_format($row['harga'], 0, ',', '.') . "</td>";
                            echo "<td><img src='upload/{$row['foto_barang']}' alt='Foto Barang' class='img-thumbnail' width='100' height='100' style='cursor: pointer;' data-bs-toggle='modal' data-bs-target='#imageModal' onclick='showImage(\"upload/{$row['foto_barang']}\")'></td>";
                            echo "<td>{$row['tgl']}</td>";
                            echo "<td>{$row['deskripsi']}</td>";
                            echo "<td>
                                <a href='edit.php?id={$row['id']}' class='btn btn-sm btn-warning me-1'>Edit<i class='bi bi-pencil-square'></i></a>
                                <a href='delete.php?id={$row['id']}' class='btn btn-sm btn-danger' onclick='return confirm(\"Yakin ingin menghapus barang ini?\")'>Hapus<i class='bi bi-trash'></i></a>
                            </td>";
                            echo "</tr>";
                            $no++;
                        }
                        ?>
                    </tbody>
                </table>

                <a href="add.php">➕ Tambahkan data barang</a>

                <br><br><br>

                

            </div>
        </div>
    </div>
</div>


<!-- Modal Gambar -->
<div class="modal fade" id="imageModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-body">
        <img id="modalImage" src="" class="img-fluid" alt="Zoom Foto Barang">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal Info Barang -->
<div class="modal fade" id="infoModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Detail Informasi Barang</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
      </div>
      <div class="modal-body">
        <div id="infoContent"></div>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function showImage(src) {
    document.getElementById('modalImage').src = src;
}

// Tambahan fitur modal info
function showInfo(nama, kategori, jumlah, harga, foto, tanggal, deskripsi) {
    const content = `
        <div class="row">
            <div class="col-md-5">
                <img src="upload/${foto}" class="img-fluid rounded border" alt="Foto Barang">
            </div>
            <div class="col-md-7">
                <p><strong>Nama Barang:</strong> ${nama}</p>
                <p><strong>Kategori:</strong> ${kategori}</p>
                <p><strong>Jumlah Stok:</strong> ${jumlah}</p>
                <p><strong>Harga Satuan:</strong> Rp${Number(harga).toLocaleString('id-ID')}</p>
                <p><strong>Tanggal Masuk:</strong> ${tanggal}</p>
                <p><strong>Deskripsi:</strong> ${deskripsi}</p>
            </div>
        </div>
    `;
    document.getElementById('infoContent').innerHTML = content;
    const modal = new bootstrap.Modal(document.getElementById('infoModal'));
    modal.show();
}
</script>


</body>
</html>
