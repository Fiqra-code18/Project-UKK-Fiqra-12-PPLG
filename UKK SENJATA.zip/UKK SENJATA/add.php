<?php
// Include file koneksi database
include 'db.php';

session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

// Cek apakah form sudah disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil data dari form
    $nama_barang = $_POST['nama_barang'];
    $kategori_barang = $_POST['kategori_barang'];
    $jumlah = $_POST['jumlah'];
    $harga = $_POST['harga'];
    $tgl = $_POST['tgl'];
    $deskripsi = $_POST['deskripsi'];

    // Proses upload file
    $target_dir = "upload/";
    $foto_barang = $_FILES['foto_barang']['name'];
    $target_file = $target_dir . basename($foto_barang);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Validasi gambar
    $check = getimagesize($_FILES['foto_barang']['tmp_name']);
    if($check === false) {
        echo "File yang diunggah bukan gambar.";
        $uploadOk = 0;
    }

    if ($_FILES['foto_barang']['size'] > 2000000) {
        echo "Ukuran file terlalu besar (maksimal 2MB).";
        $uploadOk = 0;
    }

    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
        echo "Hanya format JPG, JPEG, dan PNG yang diperbolehkan.";
        $uploadOk = 0;
    }

    if ($uploadOk == 0) {
        echo "File tidak dapat diunggah.";
    } else {
        if (move_uploaded_file($_FILES['foto_barang']['tmp_name'], $target_file)) {
            $query = "INSERT INTO barang (nama_barang, kategori_barang, jumlah, harga, foto_barang, tgl, deskripsi) 
                      VALUES ('$nama_barang', '$kategori_barang', '$jumlah', '$harga', '$foto_barang', '$tgl', '$deskripsi')";
            if (mysqli_query($koneksi, $query)) {
                header('Location: index.php?status=success');
exit;
            } else {
                echo "Terjadi kesalahan saat menambahkan barang ke database.";
            }
        } else {
            echo "Terjadi kesalahan saat mengunggah file.";
        }
    }
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Barang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="121.jpg">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    
<div class="container mt-5">
    <h2 class="text-center">Tambah Barang</h2>
    <form action="add.php" method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="nama_barang" class="form-label">Nama Barang</label>
            <input type="text" class="form-control" id="nama_barang" name="nama_barang" required>
        </div>
        <div class="mb-3">
            <label for="kategori_barang" class="form-label">Kategori Barang</label>
            <input type="text" class="form-control" id="kategori_barang" name="kategori_barang" required>
        </div>
        <div class="mb-3">
            <label for="jumlah" class="form-label">Jumlah</label>
            <input type="number" class="form-control" id="jumlah" name="jumlah" required>
        </div>
        <div class="mb-3">
            <label for="harga" class="form-label">Harga (per satuan)</label>
            <input type="number" class="form-control" id="harga" name="harga" required>
        </div>
        <div class="mb-3">
            <label for="foto_barang" class="form-label">Foto Barang</label>
            <input type="file" class="form-control" id="foto_barang" name="foto_barang" required>
        </div>
        <div class="mb-3">
            <label for="tgl" class="form-label">Tanggal Masuk</label>
            <input type="date" class="form-control" id="tgl" name="tgl" required>
        </div>
        <div class="mb-3">
            <label for="deskripsi" class="form-label">Deskripsi Senjata</label>
            <input type="text" class="form-control" id="deskripsi" name="deskripsi" required>
        </div>
        <button type="submit" class="btn btn-primary">Tambah Barang</button>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
    </form>
</div>



</body>
</html>

