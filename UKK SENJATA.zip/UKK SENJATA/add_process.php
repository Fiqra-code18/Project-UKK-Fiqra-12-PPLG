<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_barang = $_POST['nama_barang'];
    $kategori_barang = $_POST['kategori_barang'];
    $jumlah = $_POST['jumlah'];
    $harga = $_POST['harga'];
    $tgl = $_POST['tgl'];
    $deskripsi = $_POST['deskripsi'];

    // Proses upload file
    $target_dir = "uploads/"; // Folder untuk menyimpan gambar
    $foto_barang = $_FILES['foto_barang']['name'];
    $target_file = $target_dir . basename($foto_barang);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check apakah file benar-benar gambar
    $check = getimagesize($_FILES['foto_barang']['tmp_name']);
    if($check !== false) {
        $uploadOk = 1;
    } else {
        echo "File bukan gambar.";
        $uploadOk = 0;
    }

    // Check ukuran file (misal tidak lebih dari 2MB)
    if ($_FILES['foto_barang']['size'] > 2000000) {
        echo "Ukuran file terlalu besar.";
        $uploadOk = 0;
    }

    // Hanya izinkan format tertentu (jpg, png, jpeg)
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
        echo "Hanya format JPG, JPEG, & PNG yang diizinkan.";
        $uploadOk = 0;
    }

    // Check apakah uploadOk 0
    if ($uploadOk == 0) {
        echo "Gagal upload file.";
    } else {
        // Simpan file ke folder uploads
        if (move_uploaded_file($_FILES['foto_barang']['tmp_name'], $target_file)) {
            // Simpan data barang dan nama file foto ke database
            $query = "INSERT INTO barang (nama_barang, kategori_barang, jumlah, harga, foto_barang, tgl, deskripsi) 
                      VALUES ('$nama_barang', '$kategori_barang', '$jumlah', '$harga', '$foto_barang', '$tgl', '$deskripsi')";
            if (mysqli_query($koneksi, $query)) {
                echo "Barang berhasil ditambahkan.";
                header('Location: z.php');
            } else {
                echo "Gagal menambahkan barang.";
            }
        } else {
            echo "Terjadi kesalahan saat upload file.";
        }
    }
}
?>
